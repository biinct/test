﻿ namespace VayneHunter_Reborn.Utility.Enumerations
{
    public enum Skills
    {
        Q, W, E, R
    }
}
