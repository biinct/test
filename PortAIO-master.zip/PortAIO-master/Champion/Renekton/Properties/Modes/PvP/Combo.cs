using System;
using ExorAIO.Utilities;
using LeagueSharp.SDK;
using LeagueSharp.SDK.Core.Utils;

 namespace ExorAIO.Champions.Renekton
{
    /// <summary>
    ///     The logics class.
    /// </summary>
    internal partial class Logics
    {
        /// <summary>
        ///     Called when the game updates itself.
        /// </summary>
        /// <param name="args">The <see cref="EventArgs" /> instance containing the event data.</param>
        public static void Combo(EventArgs args)
        {
            if (Bools.HasSheenBuff() ||
                !Targets.Target.LSIsValidTarget() ||
                Invulnerable.Check(Targets.Target))
            {
                return;
            }

            /// <summary>
            ///     The E Combo Logic.
            /// </summary>
            if (Vars.E.IsReady() &&
                Targets.Target.LSIsValidTarget(Vars.E.Range) &&
                !GameObjects.Player.HasBuff("renektonsliceanddicedelay") &&
                Vars.getCheckBoxItem(Vars.EMenu, "combo"))
            {
                if (Targets.Target.HealthPercent < 10 ||
                    !Targets.Target.IsUnderEnemyTurret())
                {
                    Vars.E.Cast(Targets.Target.ServerPosition);
                }
            }
        }
    }
}