﻿namespace Jhin___The_Virtuoso.Extensions
{
    internal class Manager
    {
    }
}